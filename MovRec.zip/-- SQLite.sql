-- SQLite
INSERT INTO users (Username, Password, Is_Admin)
VALUES ("Admin", "Admin123", 1);
