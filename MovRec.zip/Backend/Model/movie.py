class Movie():
    def __init__(self, movieID, Title, Description, AgeRating, Runtime, Genre):
        self._movieID = movieID
        self._Title = Title
        self._Description = Description
        self._AgeRating = AgeRating
        self._Runtime = Runtime
        self._Genre = Genre

    def get_movieID(self):
        return self._movieID

    def set_movieID(self, movieID):
        self._movieID = movieID

    def get_Title(self):
        return self._Title

    def set_Title(self, Title):
        self._Title = Title

    def get_Description(self):
        return self._Description

    def set_Description(self, Description):
        self._Description = Description

    def get_AgeRating(self):
        return self._AgeRating

    def set_AgeRating(self, AgeRating):
        self._AgeRating = AgeRating

    def get_Runtime(self):
        return self._Runtime

    def set_Runtime(self, Runtime):
        self._Runtime = Runtime

    def get_Genre(self):
        return self._Genre

    def set_Genre(self, Genre):
        self._Genre = Genre

        