start pythonw "./Backend/nea backend.pyw"
start pythonw "./frontend.pyw"