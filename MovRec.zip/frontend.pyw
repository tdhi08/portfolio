import customtkinter as ctk
import requests
import json
from PIL import Image

ctk.set_appearance_mode("dark")         
ctk.set_default_color_theme("blue")      

root = ctk.CTk()
root.title("MovRec")
root.geometry("1920x1080")
root.configure(fg_color="brown4")

frame = ctk.CTkFrame(root, width=1920, height=1080, fg_color="transparent") 
frame.place(x=0, y=0, relwidth=1, relheight=1)

BACKEND = "http://127.0.0.1:5000/"
token = ""
is_admin = 0
current_username = ""


# ---------------- Buttons ----------------
def clear_frame():
    for widget in frame.winfo_children():
        widget.destroy()

def appquit():
    root.quit()

def back_button(command=None):
    if command is None:
        command = menu_page
    btn = ctk.CTkButton(frame, text="Back", font=("Open Sans", 20, "bold"), command=command)
    btn.place(x=10, y=10)

def menu_button():
    btn = ctk.CTkButton(frame, text="Menu", font=("Open Sans", 20, "bold"), command=menu_page, width=80, height=32)
    btn.place(x=10, y=10)

def editmovie_button():
    btn = ctk.CTkButton(frame, text = "Edit Movies", font=("Open Sans", 20, "bold"), width=80, height=32, command= editmovie_page)
    btn.place(x=100, y=10)

def recommendation_button():
    btn = ctk.CTkButton(
        frame,
        text="Recommendation System",
        font=("Open Sans", 20, "bold"),
        width=80,
        height=32,
        fg_color="#1f5a94",
        hover_color="#1a4a7a",
        command=recommendation_page   
    )
    btn.place(x=1280, y=10)
# ---------------- Pages ----------------

def recommendation_page():
    clear_frame()
    back_button(command=Homepage)

    ctk.CTkLabel(frame, text="Movie Recommendations",
                 font=("Open Sans", 36, "bold")).pack(pady=30)

    genre_entry = ctk.CTkEntry(frame, width=300, placeholder_text="Genre (e.g. Action)")
    runtime_entry = ctk.CTkEntry(frame, width=300, placeholder_text="Target Runtime (minutes)")
    age_entry = ctk.CTkEntry(frame, width=300, placeholder_text="Max Age Rating")

    genre_entry.pack(pady=10)
    runtime_entry.pack(pady=10)
    ctk.CTkLabel(frame,text="(± 20–30 min range applied automatically)",font=("Open Sans", 12),text_color="gray").pack(pady=(0, 5))
    age_entry.pack(pady=10)

    results_frame = ctk.CTkFrame(frame, fg_color="transparent")
    results_frame.pack(pady=20)

    result_cards = []
    
    def get_recommendations():
        for widget in results_frame.winfo_children():
            widget.destroy()

        genre = genre_entry.get()
        runtime = runtime_entry.get()
        age = age_entry.get()

        try:
            r = requests.get(
                BACKEND + "recommend_movies",
                params={
                    "genre": genre,
                    "runtime": runtime,
                    "age_rating": age
                },
                timeout=5
            )

            movies = r.json()

            if not movies:
                ctk.CTkLabel(results_frame, text="No matches found").pack()
                return

            
            scroll = ctk.CTkScrollableFrame(results_frame, width=700, height=380,
                                            fg_color="#2b2b2b", corner_radius=12)
            scroll.pack(padx=20, pady=10)

            for m in movies:
                card = ctk.CTkFrame(scroll, fg_color="#3a3a3a", corner_radius=10, cursor="hand2")
                card.pack(fill="x", padx=12, pady=6)

                # Poster thumbnail
                img = None
                if m.get("poster"):
                    try:
                        from io import BytesIO
                        resp = requests.get(BACKEND + f"get_poster/{m['poster']}", timeout=3)
                        if resp.status_code == 200:
                            img = ctk.CTkImage(Image.open(BytesIO(resp.content)), size=(54, 80))
                    except Exception:
                        pass

                if img is None:
                    local_map = {
                        "Iron Man 3":      "posters/IronMan3.jpg",
                        "Wall-E":          "posters/WallE.jpg",
                        "The Dark Knight": "posters/DarkKnight.jpg",
                    }
                    local = local_map.get(m["title"])
                    if local:
                        try:
                            img = ctk.CTkImage(Image.open(local), size=(54, 80))
                        except Exception:
                            pass

                row_inner = ctk.CTkFrame(card, fg_color="transparent")
                row_inner.pack(fill="x", padx=16, pady=10)

                if img:
                    img_lbl = ctk.CTkLabel(row_inner, image=img, text="")
                    img_lbl.pack(side="left", padx=(0, 16))
                    result_cards.append(img)  

                info_frame = ctk.CTkFrame(row_inner, fg_color="transparent")
                info_frame.pack(side="left", fill="x", expand=True)

                ctk.CTkLabel(info_frame, text=m["title"],
                            font=("Open Sans", 18, "bold"), anchor="w").pack(anchor="w")
                ctk.CTkLabel(info_frame,
                            text=f"{m['genre']}  •  {m['runtime']} min  •  Age {m['age_rating']}+",
                            font=("Open Sans", 14), text_color="gray", anchor="w").pack(anchor="w", pady=(4, 0))

                def go(e, t=m["title"]):
                    movie_detail_page(t)

                for widget in [card, row_inner, info_frame]:
                    widget.bind("<Button-1>", go)
                for child in info_frame.winfo_children():
                    child.bind("<Button-1>", go)
                if img:
                    img_lbl.bind("<Button-1>", go)

        except Exception as e:
            print(e)
            ctk.CTkLabel(results_frame, text="Error fetching recommendations").pack()

    ctk.CTkButton(frame, text="Get Recommendations",
                font=("Open Sans", 20, "bold"),
                width=260, height=55,
                command=get_recommendations).pack(pady=20)

def movie_detail_page(movie_title):
    clear_frame()
    back_button(command=Homepage)

    outer_scroll = ctk.CTkScrollableFrame(frame, fg_color="transparent")
    outer_scroll.pack(fill="both", expand=True, padx=20, pady=(50, 10))

    try:
        r = requests.get(BACKEND + "get_movie", params={"title": movie_title}, timeout=5)
        m = r.json() if r.status_code == 200 else None
    except Exception:
        m = None

    if m is None:
        ctk.CTkLabel(outer_scroll, text="Could not load movie details.", font=("Open Sans", 20)).pack(pady=100)
        return

    content = ctk.CTkFrame(outer_scroll, fg_color="transparent")
    content.pack(pady=40)

    img = None
    if m.get("poster"):
        try:
            from io import BytesIO
            resp = requests.get(BACKEND + f"get_poster/{m['poster']}", timeout=5)
            if resp.status_code == 200:
                img = ctk.CTkImage(Image.open(BytesIO(resp.content)), size=(280, 415))
        except Exception:
            pass

    if img is None:
        local_map = {
            "Iron Man 3":      "posters/IronMan3.jpg",
            "Wall-E":          "posters/WallE.jpg",
            "The Dark Knight": "posters/DarkKnight.jpg",
        }
        local = local_map.get(m["title"])
        if local:
            try:
                img = ctk.CTkImage(Image.open(local), size=(280, 415))
            except Exception:
                pass

    if img:
        img_lbl = ctk.CTkLabel(content, image=img, text="")
        img_lbl.image = img
        img_lbl.grid(row=0, column=0, rowspan=6, padx=(0, 50), sticky="n")

    def detail_row(label, value, row):
        ctk.CTkLabel(content, text=label, font=("Open Sans", 16, "bold"),
                     anchor="w", width=120).grid(row=row, column=1, sticky="w", pady=6)
        ctk.CTkLabel(content, text=value, font=("Open Sans", 16),
                     anchor="w", wraplength=550).grid(row=row, column=2, sticky="w", pady=6)

    ctk.CTkLabel(content, text=m["title"], font=("Open Sans", 36, "bold")).grid(
        row=0, column=1, columnspan=2, sticky="w", pady=(0, 20))

    detail_row("Genre:",       m["genre"],            1)
    detail_row("Runtime:",     f"{m['runtime']} min", 2)
    detail_row("Age Rating:",  f"{m['age_rating']}+", 3)
    detail_row("Description:", m["description"],      4)

    reviews_frame = ctk.CTkFrame(outer_scroll, fg_color="transparent")

    def show_reviews():
        clear_frame()
        reviews_frame.pack(pady=(0, 20))

        try:
            r = requests.get(BACKEND + "get_reviews", params={"movie_id": m["movie_id"]}, timeout=5)
            reviews = r.json() if r.status_code == 200 else []
        except Exception:
            reviews = []

        ctk.CTkLabel(reviews_frame, text="Reviews", font=("Open Sans", 24, "bold")).pack(pady=(10, 5))

        if not reviews:
            ctk.CTkLabel(reviews_frame, text="No reviews yet. Be the first!",
                         font=("Open Sans", 15), text_color="gray").pack(pady=5)
        else:
            scroll = ctk.CTkScrollableFrame(reviews_frame, width=700, height=220,
                                            fg_color="#2b2b2b", corner_radius=12)
            scroll.pack(padx=20, pady=5)

            for rv in reviews:
                card = ctk.CTkFrame(scroll, fg_color="#3a3a3a", corner_radius=8)
                card.pack(fill="x", padx=10, pady=5)

                stars = "⭐" * rv["rating"] + "☆" * (5 - rv["rating"])
                header = f"{rv['username']}   {stars}   {rv['date'][:10]}"
                ctk.CTkLabel(card, text=header, font=("Open Sans", 14, "bold"),
                             anchor="w").pack(anchor="w", padx=12, pady=(8, 2))
                ctk.CTkLabel(card, text=rv["review_text"], font=("Open Sans", 14),
                             anchor="w", wraplength=640).pack(anchor="w", padx=12, pady=(0, 8))

        if token != "":
            ctk.CTkLabel(reviews_frame, text="Write a Review",
                         font=("Open Sans", 18, "bold")).pack(pady=(15, 5))

            rating_var = ctk.StringVar(value="5")
            rating_row = ctk.CTkFrame(reviews_frame, fg_color="transparent")
            rating_row.pack()
            ctk.CTkLabel(rating_row, text="Rating:", font=("Open Sans", 15)).pack(side="left", padx=(0, 10))
            for i in ["1", "2", "3", "4", "5"]:
                ctk.CTkRadioButton(rating_row, text=i, variable=rating_var,
                                   value=i, font=("Open Sans", 14)).pack(side="left", padx=6)

            review_box = ctk.CTkTextbox(reviews_frame, width=600, height=90, font=("Open Sans", 15))
            review_box.pack(pady=8)
            review_box.insert("1.0", "Write your review here...")

            feedback = ctk.CTkLabel(reviews_frame, text="", font=("Open Sans", 14))
            feedback.pack()

            def submit_review():
                text = review_box.get("1.0", "end").strip()
                if not text or text == "Write your review here...":
                    feedback.configure(text="⚠  Please write a review.", text_color="orange")
                    return
                try:
                    
                    username = current_username
                    resp = requests.post(BACKEND + "add_review", data={
                        "movie_id":    m["movie_id"],
                        "username":    username,
                        "rating":      rating_var.get(),
                        "review_text": text
                    }, timeout=5)
                    if resp.status_code == 200:
                        feedback.configure(text="✔  Review submitted!", text_color="green")
                        root.after(800, show_reviews)  
                    else:
                        feedback.configure(text=f"⚠  Error: {resp.text}", text_color="orange")
                except Exception as e:
                    feedback.configure(text="⚠  Could not reach server.", text_color="red")
                    print(e)

            ctk.CTkButton(reviews_frame, text="Submit Review",
                          font=("Open Sans", 16, "bold"), width=200, height=45,
                          command=submit_review).pack(pady=8)
        else:
            ctk.CTkLabel(reviews_frame, text="Log in to leave a review.",
                         font=("Open Sans", 14), text_color="gray").pack(pady=10)

    ctk.CTkButton(outer_scroll, text="See Reviews", font=("Open Sans", 18, "bold"),
                  width=200, height=45, command=show_reviews).pack(pady=(0, 10))

def menu_page():
    clear_frame()

    menu_display_label = ctk.CTkLabel(
        frame,
        text="MovRec Menu",
        font=("Open Sans", 42, "bold")
    )
    menu_display_label.pack(pady=20)

    sign_up_button = ctk.CTkButton(
        frame,
        text="Sign Up",
        font=("Open Sans", 28, "bold"),
        command=sign_up_page,
        width=220,
        height=60
    )
    sign_up_button.pack(pady=20)

    log_in_button = ctk.CTkButton(
        frame,
        text="Log In",
        font=("Open Sans", 28, "bold"),
        command=log_in_page,
        width=220,
        height=60
    )
    log_in_button.pack(pady=20)

    quit_button = ctk.CTkButton(
        frame,
        text="Quit",
        font=("Open Sans", 28, "bold"),
        command=appquit,
        width=220,
        height=60,
        fg_color="#8B0000",     
        hover_color="#A00000",
    )
    quit_button.pack(pady=20)

def sign_up_page():
    clear_frame()
    back_button()

    signup_user_entry_label = ctk.CTkLabel(frame, text="Please enter your username", font=("Open Sans", 18))
    signup_pass_entry_label = ctk.CTkLabel(frame, text="Please enter your password", font=("Open Sans", 18))

    sign_up_user = ctk.CTkEntry(frame, width=280, font=("Open Sans", 16))
    sign_up_pass = ctk.CTkEntry(frame, width=280, font=("Open Sans", 16), show="*")

    signup_user_entry_label.pack(pady=(60, 10))
    sign_up_user.pack()
    signup_pass_entry_label.pack(pady=(20, 10))
    sign_up_pass.pack()

    def signup_done_button():
        username = sign_up_user.get()
        password = sign_up_pass.get()

        print(f"Username: {username}")
        print(f"Password: {password}")

        try:
            x = requests.post(BACKEND + "signup", data={
                "Username": username,
                "Password": password
            }, timeout=5)
            response_text = x.text
        except requests.RequestException as e:
            response_text = f"Backend error: {e}"

        clear_frame()
        msg = "Sign up complete" if response_text == "Success!" else response_text
        done_response = ctk.CTkLabel(frame, text=msg, font=("Open Sans", 20))
        done_response.pack(pady=120)

        root.after(1000, clear_frame)
        root.after(1300, menu_page)

    done_button = ctk.CTkButton(frame, text="Done", font=("Open Sans", 18), width=200, command=signup_done_button)
    done_button.pack(pady=30)
    root.bind("<Return>", lambda event: signup_done_button())

def log_in_page():
    clear_frame()
    back_button()

    login_user_entry_label = ctk.CTkLabel(frame, text="Please enter your username", font=("Open Sans", 18))
    login_pass_entry_label = ctk.CTkLabel(frame, text="Please enter your password", font=("Open Sans", 18))

    log_in_user = ctk.CTkEntry(frame, width=280, font=("Open Sans", 16))
    log_in_pass = ctk.CTkEntry(frame, width=280, font=("Open Sans", 16), show="*")

    login_user_entry_label.pack(pady=(60, 10))
    log_in_user.pack()
    login_pass_entry_label.pack(pady=(20, 10))
    log_in_pass.pack()

    def login_done_button():
        global token, is_admin, current_username

        username = log_in_user.get()
        password = log_in_pass.get()
        current_username = username

        try:
            x = requests.post(
                BACKEND + "login",
                data={"Username": username, "Password": password},
                timeout=5
            )

            print("STATUS:", x.status_code)
            print("TEXT:", x.text)

            if x.status_code == 200:
                response_text = x.json()
                token = response_text["token"]
                is_admin = response_text["is_admin"]
            else:
                token = ""

        except Exception as e:
            print("Login error:", e)
            token = ""

        print("TOKEN:", token)
        print("ADMIN:", is_admin)

        if token != "":
            clear_frame()
            success_label = ctk.CTkLabel(frame, text="Login successful!", font=("Open Sans", 20), text_color="green")
            success_label.pack(pady=120)
            root.after(1000, clear_frame)
            root.after(1300, Homepage)
        else:
            clear_frame()
            error_label = ctk.CTkLabel(frame, text="Invalid username or password", font=("Open Sans", 20), text_color="red")
            error_label.pack(pady=120)
            root.after(1500, log_in_page)

    login_button = ctk.CTkButton(frame, text="Login", font=("Open Sans", 18), width=200, command=login_done_button)
    login_button.pack(pady=30)
    root.bind("<Return>", lambda event: login_done_button())

def editmovie_page():
    clear_frame()
    back_button(command=Homepage)

    title = ctk.CTkLabel(frame, text="Edit Movies", font=("Open Sans", 42, "bold"))
    title.pack(pady=(60, 40))

    add_btn = ctk.CTkButton(
        frame,
        text="Add Movie",
        font=("Open Sans", 28, "bold"),
        width=220,
        height=60,
        fg_color="#1a7a1a",
        hover_color="#228822",
        command=addmovie_page
    )
    add_btn.pack(pady=20)

    delete_btn = ctk.CTkButton(
        frame,
        text="Delete Movie",
        font=("Open Sans", 28, "bold"),
        width=220,
        height=60,
        fg_color="#8B0000",
        hover_color="#A00000",   
        command=deletemovie_page
    )
    delete_btn.pack(pady=20)


def addmovie_page():
    clear_frame()
    back_button(command=editmovie_page)

    ctk.CTkLabel(frame, text="Add a Movie", font=("Open Sans", 42, "bold")).pack(pady=(50, 30))

    form = ctk.CTkFrame(frame, fg_color="transparent")
    form.pack()

    def form_row(label_text, placeholder, row):
        ctk.CTkLabel(form, text=label_text, font=("Open Sans", 18, "bold"),
                     anchor="e", width=160).grid(row=row, column=0, padx=(0, 16), pady=12, sticky="e")
        entry = ctk.CTkEntry(form, width=380, font=("Open Sans", 16), placeholder_text=placeholder)
        entry.grid(row=row, column=1, pady=12, sticky="w")
        return entry

    title_entry      = form_row("Title",         "e.g. The Dark Knight", 0)
    genre_entry      = form_row("Genre",         "e.g. Action, Drama",   1)
    age_rating_entry = form_row("Age Rating",    "e.g. 12, 15, 18",      2)
    runtime_entry    = form_row("Runtime (min)", "e.g. 152",             3)

    ctk.CTkLabel(form, text="Description", font=("Open Sans", 18, "bold"),
                 anchor="e", width=160).grid(row=4, column=0, padx=(0, 16), pady=12, sticky="ne")
    description_box = ctk.CTkTextbox(form, width=380, height=120, font=("Open Sans", 16))
    description_box.grid(row=4, column=1, pady=12, sticky="w")

    selected_poster = {"path": None}

    ctk.CTkLabel(form, text="Poster Image", font=("Open Sans", 18, "bold"),
                 anchor="e", width=160).grid(row=5, column=0, padx=(0, 16), pady=12, sticky="e")

    poster_row = ctk.CTkFrame(form, fg_color="transparent")
    poster_row.grid(row=5, column=1, pady=12, sticky="w")

    poster_name_label = ctk.CTkLabel(poster_row, text="No file chosen",
                                     font=("Open Sans", 14), text_color="gray")
    poster_name_label.pack(side="left", padx=(0, 12))

    def choose_file():
        from tkinter import filedialog
        import os
        path = filedialog.askopenfilename(
            title="Select a poster image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.webp")]
        )
        if path:
            selected_poster["path"] = path
            poster_name_label.configure(text=os.path.basename(path), text_color="white")

    ctk.CTkButton(poster_row, text="Browse...", font=("Open Sans", 14),
                  width=110, height=32, command=choose_file).pack(side="left")

    feedback_label = ctk.CTkLabel(frame, text="", font=("Open Sans", 16))
    feedback_label.pack(pady=(10, 0))

    def submit():
        title       = title_entry.get().strip()
        genre       = genre_entry.get().strip()
        age_rating  = age_rating_entry.get().strip()
        runtime     = runtime_entry.get().strip()
        description = description_box.get("1.0", "end").strip()

        if not all([title, genre, age_rating, runtime, description]):
            feedback_label.configure(text="⚠  Please fill in all fields.", text_color="orange")
            return
        if not age_rating.isdigit() or not runtime.isdigit():
            feedback_label.configure(text="⚠  Age rating and runtime must be numbers.", text_color="orange")
            return

        try:
            files = {}
            if selected_poster["path"]:
                files["poster"] = open(selected_poster["path"], "rb")

            r = requests.post(BACKEND + "add_movie", data={
                "title": title, "description": description,
                "age_rating": age_rating, "runtime": runtime, "genre": genre
            }, files=files, timeout=5)

            if files.get("poster"):
                files["poster"].close()

            if r.status_code == 200:
                feedback_label.configure(text="✔  Movie added successfully!", text_color="green")
                root.after(1200, editmovie_page)
            else:
                feedback_label.configure(text=f"⚠  Server error: {r.text}", text_color="orange")

        except requests.RequestException as e:
            feedback_label.configure(text="⚠  Could not reach server.", text_color="red")
            print(f"Add movie error: {e}")

    ctk.CTkButton(frame, text="Submit", font=("Open Sans", 22, "bold"),
                  width=200, height=55, fg_color="#1a7a1a", hover_color="#228822",
                  command=submit).pack(pady=24)
def deletemovie_page():
    clear_frame()
    back_button(command=editmovie_page)

    ctk.CTkLabel(frame, text="Delete a Movie", font=("Open Sans", 42, "bold")).pack(pady=(50, 20))

    try:
        r = requests.get(BACKEND + "get_all_movies", timeout=5)
        movies = r.json() if r.status_code == 200 else []
    except Exception:
        movies = []

    if not movies:
        ctk.CTkLabel(frame, text="No movies found in the database.", font=("Open Sans", 18), text_color="gray").pack(pady=40)
        return

    ctk.CTkLabel(frame, text="Select a movie to delete:", font=("Open Sans", 18)).pack(pady=(0, 10))

    scroll_frame = ctk.CTkScrollableFrame(frame, width=600, height=320, fg_color="#2b2b2b", corner_radius=12)
    scroll_frame.pack(pady=10)

    selected_movie = {"id": None, "title": None}  

    row_frames = []

    def select_movie(movie, row_frame):
        selected_movie["id"]    = movie["movie_id"]
        selected_movie["title"] = movie["title"]
        feedback_label.configure(text=f'Selected: {movie["title"]}', text_color="white")
        for rf in row_frames:
            rf.configure(fg_color="#3a3a3a")
        row_frame.configure(fg_color="#6b1010")

    for movie in movies:
        row = ctk.CTkFrame(scroll_frame, fg_color="#3a3a3a", corner_radius=8)
        row.pack(fill="x", padx=10, pady=5)
        row_frames.append(row)

        info = f"{movie['title']}  |  {movie['genre']}  |  {movie['runtime']} min  |  Age {movie['age_rating']}+"
        lbl = ctk.CTkLabel(row, text=info, font=("Open Sans", 15), anchor="w", cursor="hand2")
        lbl.pack(fill="x", padx=16, pady=10)

       
        row.bind("<Button-1>", lambda e, m=movie, rf=row: select_movie(m, rf))
        lbl.bind("<Button-1>", lambda e, m=movie, rf=row: select_movie(m, rf))

    feedback_label = ctk.CTkLabel(frame, text="Click a movie to select it.", font=("Open Sans", 16), text_color="gray")
    feedback_label.pack(pady=12)

    def confirm_delete():
        if selected_movie["id"] is None:
            feedback_label.configure(text="⚠  Please select a movie first.", text_color="orange")
            return

        
        confirm_win = ctk.CTkToplevel(root)
        confirm_win.title("Confirm Delete")
        confirm_win.geometry("420x200")
        confirm_win.grab_set()  

        ctk.CTkLabel(
            confirm_win,
            text=f'Delete "{selected_movie["title"]}"?\nThis cannot be undone.',
            font=("Open Sans", 18),
            wraplength=380
        ).pack(pady=30)

        btn_row = ctk.CTkFrame(confirm_win, fg_color="transparent")
        btn_row.pack()

        def do_delete():
            confirm_win.destroy()
            try:
                r = requests.delete(BACKEND + "delete_movie", data={"movie_id": selected_movie["id"]}, timeout=5)
                if r.status_code == 200:
                    feedback_label.configure(text=f'✔  "{selected_movie["title"]}" deleted.', text_color="green")
                    root.after(1200, deletemovie_page) 
                else:
                    feedback_label.configure(text=f"⚠  Server error: {r.text}", text_color="orange")
            except Exception as e:
                feedback_label.configure(text="⚠  Could not reach server.", text_color="red")
                print(f"Delete error: {e}")

        ctk.CTkButton(btn_row, text="Yes, Delete", fg_color="#8B0000", hover_color="#A00000",
                      font=("Open Sans", 16, "bold"), width=150, command=do_delete).pack(side="left", padx=12)
        ctk.CTkButton(btn_row, text="Cancel", font=("Open Sans", 16, "bold"),
                      width=120, command=confirm_win.destroy).pack(side="left", padx=12)

    ctk.CTkButton(frame, text="Delete Selected", font=("Open Sans", 22, "bold"), width=220, height=55, fg_color="#8B0000", hover_color="#A00000", command=confirm_delete).pack(pady=10)
# ---------------- Homepage ----------------
def Homepage():
    clear_frame()
    menu_button()

    if is_admin == 1:
        editmovie_button()
    recommendation_button()
    ctk.CTkLabel(frame, text="Welcome to MovRec", font=("Open Sans", 42, "bold")).pack(pady=(40, 10))

    search_bar_frame = ctk.CTkFrame(frame, fg_color="transparent")
    search_bar_frame.pack(pady=(10, 0))

    search_entry = ctk.CTkEntry(
        search_bar_frame, width=500, height=44,
        font=("Open Sans", 18), placeholder_text="🔍  Search for a movie..."
    )
    search_entry.pack(side="left", padx=(0, 10))

    results_outer = ctk.CTkFrame(frame, fg_color="transparent")

    static_section = ctk.CTkFrame(frame, fg_color="transparent")

    ctk.CTkLabel(static_section, text="Top Rated Movies", font=("Open Sans", 22)).pack(pady=(0, 30))

    movie_container = ctk.CTkFrame(static_section, fg_color="transparent")
    movie_container.pack()

    img1 = ctk.CTkImage(Image.open("posters/IronMan3.jpg"), size=(250, 370))
    img2 = ctk.CTkImage(Image.open("posters/WallE.jpg"), size=(250, 370))
    img3 = ctk.CTkImage(Image.open("posters/DarkKnight.jpg"), size=(250, 370))

    for col, (img, title_text, rating_text) in enumerate([
        (img1, "Iron Man 3",      "⭐⭐⭐⭐☆ 4.6"),
        (img2, "Wall-E",          "⭐⭐⭐⭐⭐ 5.0"),
        (img3, "The Dark Knight", "⭐⭐⭐⭐☆ 4.3"),
    ]):
        card = ctk.CTkFrame(movie_container, corner_radius=15)
        card.grid(row=0, column=col, padx=40)
        poster_lbl = ctk.CTkLabel(card, image=img, text="", cursor="hand2")
        poster_lbl.pack(pady=10, padx=10)
        poster_lbl.bind("<Button-1>", lambda e, t=title_text: movie_detail_page(t))
        ctk.CTkLabel(card, text=title_text, font=("Open Sans", 16, "bold")).pack(pady=(0, 4))
        ctk.CTkLabel(card, text=rating_text, font=("Open Sans", 14)).pack(pady=(0, 10))

    static_section.pack(pady=(20, 0))

    all_movies = []
    try:
        r = requests.get(BACKEND + "get_all_movies", timeout=5)
        if r.status_code == 200:
            all_movies = r.json()
    except Exception:
        pass

    result_cards = []   

    def render_results(movies):
        clear_frame()
        result_cards.clear()

        if not movies:
            ctk.CTkLabel(results_outer, text="No movies found.",
                         font=("Open Sans", 16), text_color="gray").pack(pady=20)
            return

        scroll = ctk.CTkScrollableFrame(results_outer, width=900, height=420,fg_color="#2b2b2b", corner_radius=12)
        scroll.pack(padx=20, pady=10)

        for movie in movies:
            card = ctk.CTkFrame(scroll, fg_color="#3a3a3a", corner_radius=10, cursor="hand2")
            card.pack(fill="x", padx=12, pady=6)

            img = None
            if movie.get("poster"):
                try:
                    from io import BytesIO
                    resp = requests.get(BACKEND + f"get_poster/{movie['poster']}", timeout=3)
                    if resp.status_code == 200:
                        img = ctk.CTkImage(Image.open(BytesIO(resp.content)), size=(54, 80))
                except Exception:
                    pass

            if img is None:
                local_map = {
                    "Iron Man 3":      "posters/IronMan3.jpg",
                    "Wall-E":          "posters/WallE.jpg",
                    "The Dark Knight": "posters/DarkKnight.jpg",
                }
                local = local_map.get(movie["title"])
                if local:
                    try:
                        img = ctk.CTkImage(Image.open(local), size=(54, 80))
                    except Exception:
                        pass

            row_inner = ctk.CTkFrame(card, fg_color="transparent")
            row_inner.pack(fill="x", padx=16, pady=10)

            if img:
                img_lbl = ctk.CTkLabel(row_inner, image=img, text="")
                img_lbl.image = img
                img_lbl.pack(side="left", padx=(0, 16))
                result_cards.append(img)   

            info_frame = ctk.CTkFrame(row_inner, fg_color="transparent")
            info_frame.pack(side="left", fill="x", expand=True)

            ctk.CTkLabel(info_frame, text=movie["title"],
                         font=("Open Sans", 18, "bold"), anchor="w").pack(anchor="w")
            ctk.CTkLabel(info_frame,
                         text=f"{movie['genre']}  •  {movie['runtime']} min  •  Age {movie['age_rating']}+",
                         font=("Open Sans", 14), text_color="gray", anchor="w").pack(anchor="w", pady=(4, 0))

            def go(e, t=movie["title"]):
                movie_detail_page(t)

            for widget in [card, row_inner, info_frame]:
                widget.bind("<Button-1>", go)
            for child in info_frame.winfo_children():
                child.bind("<Button-1>", go)
            if img:
                img_lbl.bind("<Button-1>", go)

    def on_search(*_):
        query = search_entry.get().strip().lower()
        if query == "":
            results_outer.pack_forget()
            static_section.pack(pady=(20, 0))
        else:
            static_section.pack_forget()
            matched = [m for m in all_movies if query in m["title"].lower()]
            render_results(matched)
            results_outer.pack(pady=(15, 0))

    search_entry.bind("<KeyRelease>", on_search) 

menu_page()
root.mainloop()


